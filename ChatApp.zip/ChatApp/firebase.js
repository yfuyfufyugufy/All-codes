import { initializeApp } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-app.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";

const firebaseConfig = {
    apiKey: "AIzaSyAlhOsVnJAswhPbLvnxmRp6FCMv0gSiv-c",
  authDomain: "mychat-5b89c.firebaseapp.com",
  databaseURL: "https://mychat-5b89c-default-rtdb.firebaseio.com",
  projectId: "mychat-5b89c",
  storageBucket: "mychat-5b89c.firebasestorage.app",
  messagingSenderId: "693724848521",
  appId: "1:693724848521:web:ed7d8d3b9a2e0c15c64158",
  measurementId: "G-EPG36V38L5"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export { db };