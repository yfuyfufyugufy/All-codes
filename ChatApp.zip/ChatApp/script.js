import { db } from "./firebase.js";

import {
    collection,
    addDoc,
    serverTimestamp,
    query,
    orderBy,
    onSnapshot
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";

const username =
    localStorage.getItem("username") ||
    prompt("Choose a username:");

localStorage.setItem("username", username);

const messagesDiv = document.getElementById("messages");
const input = document.getElementById("messageInput");
const sendBtn = document.getElementById("sendBtn");

sendBtn.onclick = async () => {
    if (input.value.trim() === "") return;

    await addDoc(collection(db, "messages"), {
        username,
        text: input.value,
        time: serverTimestamp()
    });

    input.value = "";
};

const q = query(
    collection(db, "messages"),
    orderBy("time")
);

onSnapshot(q, (snapshot) => {
    messagesDiv.innerHTML = "";

    snapshot.forEach((doc) => {
        const msg = doc.data();

        messagesDiv.innerHTML += `
            <div class="message">
                <b>${msg.username}</b><br>
                ${msg.text}
            </div>
        `;
    });

    messagesDiv.scrollTop = messagesDiv.scrollHeight;
});